from datetime import datetime

import mlflow
import numpy as np
import pandas as pd
import pyspark
from lightgbm import LGBMRegressor
from loguru import logger
from mlflow.models import infer_signature
from mlflow.utils.environment import _mlflow_conda_env
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline

from hotel_booking.config import ProjectConfig, Tags


class CatToIntTransformer(BaseEstimator, TransformerMixin):
    """
    Transformer that encodes categorical columns as integer codes for LightGBM.
    Unknown categories at transform time are encoded as -1.
    """
    def __init__(self, cat_features: list[str]) -> None:
        """Initialize the transformer with categorical feature names."""
        self.cat_features = cat_features
        self.cat_maps_ = {}

    def fit(self, X: pd.DataFrame, y=None) -> None:
        """Fit the transformer to the DataFrame X."""
        self.fit_transform(X)
        return self

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        """Fit and transform the DataFrame X."""
        X = X.copy()
        for col in self.cat_features:
            c = pd.Categorical(X[col])
            # Build mapping: {category: code}
            self.cat_maps_[col] = dict(zip(c.categories, range(len(c.categories)), strict=False))
            X[col] = X[col].map(lambda val, col=col: self.cat_maps_[col].get(val, -1)).astype("category")
        return X

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform the DataFrame X by encoding categorical features as integers."""
        X = X.copy()
        for col in self.cat_features:
            X[col] = X[col].map(lambda val, col=col: self.cat_maps_[col].get(val, -1)).astype("category")
        return X

class LightGBMModel:
    """A basic model class for house price prediction using LightGBM.

    This class handles data loading, feature preparation, model training, and MLflow logging.
    """
    def __init__(self, config: ProjectConfig) -> None:
        """Initialize the LightGBM model."""
        self.config = config
        self.cat_features = self.config.cat_features

    def train(self, X_train: pd.DataFrame, y_train: pd.Series, parameters: dict= None) -> None:
        """Prepare features and train the model.

        :param X_train: Training features as a DataFrame
        :param y_train: Training target as a Series
        """
        if parameters is None:
            self.parameters = self.config.parameters
        else:
            self.parameters = parameters

        preprocessor = ColumnTransformer(
            transformers=[("cat", CatToIntTransformer(self.cat_features), self.cat_features)],
            remainder="passthrough"
        )
        self.pipeline = Pipeline(
            steps=[("preprocessor", preprocessor),
                   ("regressor", LGBMRegressor(**self.parameters))])
        logger.info("🚀 Starting training...")
        self.pipeline.fit(X_train, y_train)

    def compute_metrics(self, X_test: pd.DataFrame, y_test: pd.Series) -> dict:
        """Compute regression metrics.

        :param X_test: Test features
        :param y_test: True target values
        :return: Dictionary with mse, rmse, mae, and r2_score
        """
        y_pred = self.pipeline.predict(X_test)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        self.metrics = {
            "mse": mse,
            "rmse": rmse,
            "mae": mean_absolute_error(y_test, y_pred),
            "r2_score": r2_score(y_test, y_pred),
        }
        return self.metrics

    def log_model(self, experiment_name: str,
                  tags: Tags,
                  X_test: pd.DataFrame,
                  y_test: pd.Series,
                  code_paths: list,
                  train_set_spark: pyspark.sql.DataFrame,
                  train_query: str,
                  test_set_spark: pyspark.sql.DataFrame,
                  test_query: str) -> None:
        """Log the model to MLflow."""
        tags = tags.to_dict()
        mlflow.set_experiment(experiment_name)
        with mlflow.start_run(run_name=f"lightgbm-training-{datetime.now().strftime('%Y-%m-%d')}",
                      description="LightGBM model training", tags=tags):
            mlflow.log_params(self.parameters)
            self.compute_metrics(X_test, y_test)
            mlflow.log_params(self.config.parameters)
            mlflow.log_metrics(self.metrics)
            signature = infer_signature(
                model_input=X_test, model_output=self.pipeline.predict(X_test)
            )
            additional_pip_deps = [f"code/{package.split("/")[-1]}" for package in code_paths]
            conda_env = _mlflow_conda_env(additional_pip_deps=additional_pip_deps)

            training = mlflow.data.from_spark(
                df=train_set_spark,
                sql=train_query
            )
            testing = mlflow.data.from_spark(
                df=test_set_spark,
                sql=test_query
            )
            mlflow.log_input(training, context="training")
            mlflow.log_input(testing, context="testing")

            model_info = mlflow.sklearn.log_model(
                sk_model=self.pipeline,
                name="lightgbm-pipeline",
                signature=signature,
                code_paths=code_paths,
                conda_env=conda_env
            )
            return model_info
